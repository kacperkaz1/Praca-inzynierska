require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "fitmajster"
});

db.connect((err) => {
    if (err) {
        console.error(" Błąd połączenia z bazą:", err);
        return;
    }
    console.log(" Połączono z bazą MySQL");
});

// ============================================
// PRODUKTY
// ============================================

app.get("/api/products", (req, res) => {
    db.query("SELECT * FROM products ORDER BY name", (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.get("/api/products/search", (req, res) => {
    const query = req.query.q || "";
    db.query(
        "SELECT * FROM products WHERE name LIKE ? ORDER BY name LIMIT 20",
        [`%${query}%`],
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        }
    );
});

app.post("/api/products", (req, res) => {
    const { name, calories, protein, carbs, fat } = req.body;
    
    if (!name || !calories) {
        return res.status(400).json({ error: "Nazwa i kalorie są wymagane" });
    }

    db.query(
        "INSERT INTO products (name, calories, protein, carbs, fat) VALUES (?, ?, ?, ?, ?)",
        [name, calories, protein || 0, carbs || 0, fat || 0],
        (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ 
                message: "Produkt dodany!", 
                id: result.insertId,
                product: { id: result.insertId, name, calories, protein, carbs, fat }
            });
        }
    );
});

// ============================================
// BIBLIOTEKA POSIŁKÓW (Gotowe posiłki z tabeli meals)
// ============================================

app.get("/api/library/meals", (req, res) => {
    const query = req.query.q || "";
    
    // POPRAWKA: Pobieramy bezpośrednio z tabeli meals (nie używamy meal_items)
    db.query(
        `SELECT id, name, kategoria, kcal as total_calories, 
         bialko as total_protein, weglowodany as total_carbs, 
         tluszcze as total_fat, notes as ingredients
         FROM meals
         WHERE name LIKE ?
         ORDER BY name
         LIMIT 50`,
        [`%${query}%`],
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        }
    );
});

// ============================================
// DZIENNIK (user_diary - nowa tabela)
// ============================================

// Pobierz wpisy z dziennika na dany dzień
app.get("/api/diary/date/:date", (req, res) => {
    const date = req.params.date;
    
    db.query(
        `SELECT d.*, m.name as meal_name, m.kcal, m.bialko, m.weglowodany, m.tluszcze,
         p.name as product_name, p.calories, p.protein, p.carbs, p.fat
         FROM user_diary d
         LEFT JOIN meals m ON d.meal_id = m.id AND d.type = 'meal'
         LEFT JOIN products p ON d.product_id = p.id AND d.type = 'product'
         WHERE DATE(d.date) = ?
         ORDER BY d.time`,
        [date],
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            
            // Oblicz kalorie i makro dla każdego wpisu
            const processed = results.map(row => {
                let calories = 0, protein = 0, carbs = 0, fat = 0;
                
                if (row.type === 'meal') {
                    calories = row.kcal || 0;
                    protein = row.bialko || 0;
                    carbs = row.weglowodany || 0;
                    fat = row.tluszcze || 0;
                } else if (row.type === 'product') {
                    const multiplier = (row.quantity || 100) / 100;
                    calories = (row.calories || 0) * multiplier;
                    protein = (row.protein || 0) * multiplier;
                    carbs = (row.carbs || 0) * multiplier;
                    fat = (row.fat || 0) * multiplier;
                }
                
                return {
                    id: row.id,
                    name: row.name,
                    type: row.type,
                    time: row.time,
                    quantity: row.quantity,
                    total_calories: Math.round(calories),
                    total_protein: Math.round(protein),
                    total_carbs: Math.round(carbs),
                    total_fat: Math.round(fat),
                    item_name: row.meal_name || row.product_name
                };
            });
            
            res.json(processed);
        }
    );
});

// Dodaj wpis do dziennika
app.post("/api/diary", (req, res) => {
    const { name, date, time, type, meal_id, product_id, quantity } = req.body;
    
    if (!name || !date || !type) {
        return res.status(400).json({ error: "Brak wymaganych pól" });
    }

    db.query(
        "INSERT INTO user_diary (name, date, time, type, meal_id, product_id, quantity) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [name, date, time || '12:00:00', type, meal_id || null, product_id || null, quantity || 100],
        (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ 
                message: "Dodano do dziennika!", 
                id: result.insertId 
            });
        }
    );
});

// Usuń wpis z dziennika
app.delete("/api/diary/:id", (req, res) => {
    const id = req.params.id;
    
    db.query("DELETE FROM user_diary WHERE id = ?", [id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Usunięto z dziennika!" });
    });
});

// ============================================
// STATYSTYKI
// ============================================

app.get("/api/stats/today", (req, res) => {
    const today = new Date().toISOString().split('T')[0];
    
    db.query(
        `SELECT d.*, 
         m.kcal as meal_kcal, m.bialko as meal_protein, m.weglowodany as meal_carbs, m.tluszcze as meal_fat,
         p.calories as prod_calories, p.protein as prod_protein, p.carbs as prod_carbs, p.fat as prod_fat
         FROM user_diary d
         LEFT JOIN meals m ON d.meal_id = m.id AND d.type = 'meal'
         LEFT JOIN products p ON d.product_id = p.id AND d.type = 'product'
         WHERE DATE(d.date) = ?`,
        [today],
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            
            let totalCal = 0, totalProt = 0, totalCarbs = 0, totalFat = 0;
            
            results.forEach(row => {
                if (row.type === 'meal') {
                    totalCal += row.meal_kcal || 0;
                    totalProt += row.meal_protein || 0;
                    totalCarbs += row.meal_carbs || 0;
                    totalFat += row.meal_fat || 0;
                } else if (row.type === 'product') {
                    const mult = (row.quantity || 100) / 100;
                    totalCal += (row.prod_calories || 0) * mult;
                    totalProt += (row.prod_protein || 0) * mult;
                    totalCarbs += (row.prod_carbs || 0) * mult;
                    totalFat += (row.prod_fat || 0) * mult;
                }
            });
            
            res.json({
                total_calories: totalCal,
                total_protein: totalProt,
                total_carbs: totalCarbs,
                total_fat: totalFat
            });
        }
    );
});

// ============================================
// PLANY ŻYWIENIOWE
// ============================================

// Pobierz wszystkie plany
app.get("/api/plans", (req, res) => {
    db.query("SELECT * FROM plans ORDER BY created_at DESC", (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(results);
    });
  });
  
  // Pobierz szczegóły planu (wszystkie posiłki na 7 dni)
  app.get("/api/plans/:id", (req, res) => {
    const planId = req.params.id;
    db.query(
      `SELECT pi.*, m.name as meal_name, m.kcal, m.bialko, m.weglowodany, m.tluszcze, m.kategoria
       FROM plan_items pi
       JOIN meals m ON pi.meal_id = m.id
       WHERE pi.plan_id = ?
       ORDER BY pi.day_number, 
         CASE 
           WHEN m.kategoria = 'Śniadanie' THEN 1
           WHEN m.kategoria = 'Obiad' THEN 2
           WHEN m.kategoria = 'Kolacja' THEN 3
           WHEN m.kategoria = 'Przekąska' THEN 4
           ELSE 5
         END`,
      [planId],
      (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
      }
    );
  });
  
  // Utwórz nowy plan z niestandardową nazwą
  app.post("/api/plans/create", (req, res) => {
    const { name, calories, customMeals } = req.body;
    
    if (!name || !calories) {
      return res.status(400).json({ error: "Nazwa i kalorie są wymagane" });
    }
  
    const description = `Plan ${calories} kcal/dzień`;
    
    db.query(
      "INSERT INTO plans (name, description, calories, created_at) VALUES (?, ?, ?, NOW())",
      [name, description, calories],
      (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        
        const planId = result.insertId;
  
        // Jeśli są niestandardowe posiłki, dodaj je
        if (customMeals && customMeals.length > 0) {
          const planItems = customMeals.map(meal => [
            planId,
            meal.day_number,
            meal.meal_id,
            meal.meal_time
          ]);
  
          db.query(
            "INSERT INTO plan_items (plan_id, day_number, meal_id, meal_time) VALUES ?",
            [planItems],
            (err2) => {
              if (err2) return res.status(500).json({ error: err2.message });
              res.json({
                message: "Plan utworzony!",
                plan_id: planId
              });
            }
          );
        } else {
          res.json({
            message: "Plan utworzony (bez posiłków)",
            plan_id: planId
          });
        }
      }
    );
  });
  
// Automatyczne generowanie planu 
app.post("/api/plans/generate", async (req, res) => {
  const { type, calories, name } = req.body;
  
  if (!calories || calories <= 0) {
    return res.status(400).json({ error: "Podaj poprawną liczbę kalorii" });
  }

  const mealDistribution = {
    'Śniadanie': 0.25,
    'Obiad': 0.40,
    'Kolacja': 0.25,
    'Przekąska': 0.10
  };

  const targetCalories = {
    'Śniadanie': Math.round(calories * mealDistribution['Śniadanie']),
    'Obiad': Math.round(calories * mealDistribution['Obiad']),
    'Kolacja': Math.round(calories * mealDistribution['Kolacja']),
    'Przekąska': Math.round(calories * mealDistribution['Przekąska'])
  };

  const planNames = {
    'reduction': 'Redukcja',
    'maintenance': 'Utrzymanie',
    'mass': 'Masa Mięśniowa'
  };

  const defaultName = name || `Plan ${planNames[type] || 'Custom'} - ${calories} kcal`;
  const description = `Automatyczny plan ${type} - ${calories} kcal/dzień`;

  try {
    // 1. Utwórz plan
    const planResult = await new Promise((resolve, reject) => {
      db.query(
        "INSERT INTO plans (name, description, calories, created_at) VALUES (?, ?, ?, NOW())",
        [defaultName, description, calories],
        (err, result) => {
          if (err) reject(err);
          else resolve(result);
        }
      );
    });

    const planId = planResult.insertId;
    const planItems = [];

    // 2. Pobierz posiłki dla każdego dnia
    for (let day = 1; day <= 7; day++) {
      for (const kategoria of ['Śniadanie', 'Obiad', 'Kolacja', 'Przekąska']) {
        const targetKcal = targetCalories[kategoria];
        
        const meals = await new Promise((resolve, reject) => {
          db.query(
            `SELECT id, name, kategoria, kcal
             FROM meals
             WHERE kategoria = ?
             ORDER BY ABS(kcal - ?)
             LIMIT 1`,
            [kategoria, targetKcal],
            (err, results) => {
              if (err) reject(err);
              else resolve(results);
            }
          );
        });

        if (meals && meals.length > 0) {
          const meal = meals[0];
          planItems.push([planId, day, meal.id, kategoria]);
        }
      }
    }

    // 3. Zapisz wszystkie posiłki
    if (planItems.length > 0) {
      await new Promise((resolve, reject) => {
        db.query(
          "INSERT INTO plan_items (plan_id, day_number, meal_id, meal_time) VALUES ?",
          [planItems],
          (err) => {
            if (err) reject(err);
            else resolve();
          }
        );
      });

      res.json({
        message: "Plan wygenerowany!",
        plan_id: planId,
        meals_added: planItems.length
      });
    } else {
      res.json({
        message: "Plan utworzony, ale brak posiłków w bibliotece",
        plan_id: planId
      });
    }

  } catch (error) {
    console.error("Błąd generowania planu:", error);
    res.status(500).json({ error: error.message });
  }
});

  
  // Usuń plan
  app.delete("/api/plans/:id", (req, res) => {
    const planId = req.params.id;
    db.query("DELETE FROM plan_items WHERE plan_id = ?", [planId], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      db.query("DELETE FROM plans WHERE id = ?", [planId], (err2) => {
        if (err2) return res.status(500).json({ error: err2.message });
        res.json({ message: "Plan usunięty!" });
      });
    });
  });
  


// ============================================
// DODAWANIE POSIŁKU DO BIBLIOTEKI
// ============================================

app.post("/api/meals", (req, res) => {
    const { name, kategoria, kcal, bialko, weglowodany, tluszcze, notes } = req.body;
    
    if (!name || !kcal) {
        return res.status(400).json({ error: "Nazwa i kalorie są wymagane" });
    }

    db.query(
        "INSERT INTO meals (name, kategoria, kcal, bialko, weglowodany, tluszcze, notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [name, kategoria || 'Obiad', kcal, bialko || 0, weglowodany || 0, tluszcze || 0, notes || ''],
        (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ 
                message: "Posiłek dodany!", 
                id: result.insertId
            });
        }
    );
});

// ============================================
// POWIADOMIENIA
// ============================================

// Pobierz nieprzeczytane powiadomienia
app.get("/api/notifications", (req, res) => {
  const userId = 1; // Docelowo z sesji/tokena
  
  db.query(
    `SELECT * FROM notifications 
     WHERE user_id = ? 
     ORDER BY time DESC 
     LIMIT 10`,
    [userId],
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(results);
    }
  );
});

// Oznacz powiadomienie jako przeczytane
app.put("/api/notifications/:id/read", (req, res) => {
  const notificationId = req.params.id;
  
  db.query(
    "UPDATE notifications SET is_sent = 1 WHERE id = ?",
    [notificationId],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Powiadomienie oznaczone jako przeczytane" });
    }
  );
});

// Generuj powiadomienia na podstawie dziennika żywienia
app.post("/api/notifications/check-daily", (req, res) => {
  const userId = 1; // Docelowo z sesji
  const today = new Date().toISOString().split('T')[0];
  
  // Pobierz cel kaloryczny użytkownika (z aktywnego planu)
  db.query(
    `SELECT calories FROM plans 
     WHERE id = (SELECT plan_id FROM user_plans WHERE user_id = ? ORDER BY created_at DESC LIMIT 1)`,
    [userId],
    (err, planResults) => {
      if (err || !planResults.length) {
        return res.status(400).json({ error: "Brak aktywnego planu" });
      }
      
      const targetCalories = planResults[0].calories;
      
      // Oblicz sumę kalorii z dziennika na dzisiaj
      db.query(
        `SELECT SUM(m.kcal * ud.quantity) as total_calories
         FROM user_diary ud
         JOIN meals m ON ud.meal_id = m.id
         WHERE ud.user_id = ? AND DATE(ud.date) = ?`,
        [userId, today],
        (err2, diaryResults) => {
          if (err2) return res.status(500).json({ error: err2.message });
          
          const totalCalories = diaryResults[0].total_calories || 0;
          const difference = totalCalories - targetCalories;
          const percentOfTarget = Math.round((totalCalories / targetCalories) * 100);
          
          let notification = null;
          
          // Przekroczenie kalorii (>110%)
          if (percentOfTarget > 110) {
            notification = {
              title: "Cel kalorii",
              message: `Osiągnąłeś ${percentOfTarget}% dziennego celu! (${Math.round(totalCalories)} / ${targetCalories} kcal)`,
              time: new Date()
            };
          }
          // Nie spełnienie kalorii (<80%)
          else if (percentOfTarget < 80 && totalCalories > 0) {
            notification = {
              title: "Cel kalorii",
              message: `Osiągnąłeś tylko ${percentOfTarget}% dziennego celu. Zjedz coś!`,
              time: new Date()
            };
          }
          // Osiągnięcie celu (90-110%)
          else if (percentOfTarget >= 90 && percentOfTarget <= 110) {
            notification = {
              title: "Gratulacje!",
              message: `Tydzień bez pominięć! Trzymaj tempo! 🎉`,
              time: new Date()
            };
          }
          
          if (notification) {
            db.query(
              "INSERT INTO notifications (user_id, title, message, time, is_sent) VALUES (?, ?, ?, ?, 0)",
              [userId, notification.title, notification.message, notification.time],
              (err3, result) => {
                if (err3) return res.status(500).json({ error: err3.message });
                res.json({
                  message: "Powiadomienie utworzone",
                  notification_id: result.insertId,
                  stats: { totalCalories, targetCalories, percentOfTarget }
                });
              }
            );
          } else {
            res.json({ message: "Brak nowych powiadomień" });
          }
        }
      );
    }
  );
});

// Usuń powiadomienie
app.delete("/api/notifications/:id", (req, res) => {
  const notificationId = req.params.id;
  
  db.query(
    "DELETE FROM notifications WHERE id = ?",
    [notificationId],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Powiadomienie usunięte" });
    }
  );
});

// Ręczne tworzenie powiadomienia (po sekcji POWIADOMIENIA)
app.post("/api/notifications/create-manual", (req, res) => {
  const { title, message } = req.body;
  const userId = 1;
  
  db.query(
    "INSERT INTO notifications (user_id, title, message, time, is_sent) VALUES (?, ?, ?, NOW(), 0)",
    [userId, title, message],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Powiadomienie utworzone", id: result.insertId });
    }
  );
});



// Test
app.get("/", (req, res) => {
    res.json({ message: "FitMajster API v3.0 działa!" });
});

app.listen(PORT, () => {
    console.log(` Backend działa na http://localhost:${PORT}`);
});
