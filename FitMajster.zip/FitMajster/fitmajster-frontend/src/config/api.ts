const API_BASE_URL = 'http://localhost:5000';

export const api = {
  // Produkty
  getAllProducts: async () => {
    const response = await fetch(`${API_BASE_URL}/api/products`);
    return response.json();
  },

  searchProducts: async (query: string) => {
    const response = await fetch(`${API_BASE_URL}/api/products/search?q=${encodeURIComponent(query)}`);
    return response.json();
  },

  addProduct: async (data: any) => {
    const response = await fetch(`${API_BASE_URL}/api/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return response.json();
  },

  // Biblioteka posiłków
  searchLibraryMeals: async (query: string) => {
    const response = await fetch(`${API_BASE_URL}/api/library/meals?q=${encodeURIComponent(query)}`);
    return response.json();
  },

  // Dziennik (user_diary)
  getDiaryByDate: async (date: string) => {
    const response = await fetch(`${API_BASE_URL}/api/diary/date/${date}`);
    return response.json();
  },

  addToDiary: async (data: any) => {
    const response = await fetch(`${API_BASE_URL}/api/diary`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return response.json();
  },

  deleteFromDiary: async (id: number) => {
    const response = await fetch(`${API_BASE_URL}/api/diary/${id}`, {
      method: 'DELETE'
    });
    return response.json();
  },

  // Statystyki
  getTodayStats: async () => {
    const response = await fetch(`${API_BASE_URL}/api/stats/today`);
    return response.json();
  },

  // Plany
  getPlans: async () => {
    const response = await fetch(`${API_BASE_URL}/api/plans`);
    return response.json();
  },

  getPlanDetails: async (id: number) => {
    const response = await fetch(`${API_BASE_URL}/api/plans/${id}`);
    return response.json();
  },

  // ZMODYFIKOWANE - teraz przyjmuje typ i kalorie
  generatePlan: async (type: string, calories: number) => {
    const response = await fetch(`${API_BASE_URL}/api/plans/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, calories })
    });
    return response.json();
  },

  deletePlan: async (id: number) => {
    const response = await fetch(`${API_BASE_URL}/api/plans/${id}`, {
      method: 'DELETE'
    });
    return response.json();
  },
};
