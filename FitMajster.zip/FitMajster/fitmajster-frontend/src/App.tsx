import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Library from "./pages/Library";
import Plans from "./pages/Plans";
import About from "./pages/About";
import NotFound from "./pages/NotFound";
import Notifications from "./components/Notifications";
import { useState, useEffect } from "react";


const queryClient = new QueryClient();

const navItems = [
  { path: "/", label: "Dashboard", icon: "📊" },
  { path: "/library", label: "Biblioteka", icon: "📚" },
  { path: "/plans", label: "Plany", icon: "📋" },
  { path: "/about", label: "O Projekcie", icon: "ℹ️" }
];

const Navigation = () => {
  const location = useLocation();
  const [tipIndex, setTipIndex] = useState(0);
  
  const tips = [
    { icon: "💧", text: "Pij min. 2L wody dziennie!" },
    { icon: "🥗", text: "Jedz 5 porcji warzyw i owoców!" },
    { icon: "💪", text: "30 min aktywności dziennie!" },
    { icon: "😴", text: "Śpij 7-8 godzin każdej nocy!" },
    { icon: "🍎", text: "Przekąski nie muszą być niezdrowe!" },
    { icon: "🏃", text: "Ruch to podstawa zdrowego życia!" },
    { icon: "🥤", text: "Unikaj słodkich napojów!" },
    { icon: "🧘", text: "Pamiętaj o rozciąganiu!" },
    { icon: "🎯", text: "Wyznaczaj realistyczne cele!" },
    { icon: "📊", text: "Monitoruj swoje postępy!" }
  ];

  // Zmiana wskazówki co 10 sekund
  useEffect(() => {
    const interval = setInterval(() => {
      setTipIndex((prev) => (prev + 1) % tips.length);
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const currentTip = tips[tipIndex];
  
  return (
    <nav style={{
      width: 280,
      background: "linear-gradient(180deg, rgba(255,255,255,0.95) 0%, rgba(255,255,255,0.9) 100%)",
      padding: "30px 20px",
      boxShadow: "4px 0 20px rgba(0,0,0,0.1)",
      backdropFilter: "blur(10px)",
      borderRadius: "0 30px 30px 0"
    }}>
      <div style={{
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        WebkitBackgroundClip: "text",
        WebkitTextFillColor: "transparent",
        fontSize: 32,
        fontWeight: 900,
        marginBottom: 40,
        textAlign: "center",
        letterSpacing: "-1px"
      }}>
        💪 FitMajster
      </div>
      
      <ul style={{ listStyle: "none", padding: 0 }}>
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <li key={item.path} style={{ marginBottom: 12 }}>
              <Link 
                to={item.path}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 15,
                  padding: "14px 20px",
                  borderRadius: 15,
                  textDecoration: "none",
                  fontSize: 16,
                  fontWeight: 600,
                  background: isActive 
                    ? "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
                    : "transparent",
                  color: isActive ? "white" : "#4a5568",
                  boxShadow: isActive ? "0 4px 15px rgba(102, 126, 234, 0.4)" : "none",
                  transform: isActive ? "translateX(5px)" : "none",
                  transition: "all 0.3s ease"
                }}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.background = "rgba(102, 126, 234, 0.1)";
                    e.currentTarget.style.transform = "translateX(5px)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.background = "transparent";
                    e.currentTarget.style.transform = "none";
                  }
                }}
              >
                <span style={{ fontSize: 22 }}>{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>

      {/* Wskazówka dnia z animacją */}
      <div style={{
        marginTop: 50,
        padding: 20,
        background: "linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)",
        borderRadius: 15,
        textAlign: "center",
        animation: "fadeIn 0.5s ease"
      }}>
        <div style={{ fontSize: 14, color: "#718096", marginBottom: 8 }}>
          💡 Wskazówka dnia
        </div>
        <div style={{ 
          fontSize: 24, 
          marginBottom: 8,
          animation: "bounceIn 0.6s ease"
        }}>
          {currentTip.icon}
        </div>
        <div style={{ 
          fontSize: 12, 
          color: "#4a5568", 
          fontWeight: 500,
          animation: "slideIn 0.4s ease"
        }}>
          {currentTip.text}
        </div>
      </div>
    </nav>
  );
};


const App = () => (
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <div style={{ 
        display: "flex", 
        minHeight: "100vh",
        padding: 20,
        gap: 20
      }}>
        <Navigation />
        <Notifications />
        
        <main style={{ 
          flex: 1,
          background: "rgba(255, 255, 255, 0.95)",
          borderRadius: 30,
          padding: 40,
          boxShadow: "0 10px 40px rgba(0,0,0,0.15)",
          backdropFilter: "blur(10px)",
          overflowY: "auto",
          animation: "fadeIn 0.5s ease"
        }}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/library" element={<Library />} />
            <Route path="/plans" element={<Plans />} />
            <Route path="/about" element={<About />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;
