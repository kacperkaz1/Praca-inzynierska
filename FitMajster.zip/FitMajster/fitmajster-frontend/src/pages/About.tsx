const About = () => {
    return (
      <div>
        <h1 style={{
          fontSize: 42,
          fontWeight: 900,
          background: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          marginBottom: 10
        }}>
          O Projekcie
        </h1>
        <p style={{ fontSize: 18, color: "#718096", marginBottom: 40 }}>
          FitMajster - Twój osobisty asystent żywieniowy 💪
        </p>
  
        <div style={{
          display: "grid",
          gap: 30
        }}>
          {/* Sekcja 1 */}
          <div style={{
            background: "white",
            padding: 40,
            borderRadius: 20,
            boxShadow: "0 4px 15px rgba(0,0,0,0.08)"
          }}>
            <h2 style={{ fontSize: 28, fontWeight: 700, color: "#2d3748", marginBottom: 20 }}>
              📖 Czym jest FitMajster?
            </h2>
            <p style={{ fontSize: 16, color: "#4a5568", lineHeight: 1.8, marginBottom: 15 }}>
              FitMajster to kompleksowa aplikacja webowa do zarządzania dietą i treningami. 
              Pozwala na śledzenie spożytych kalorii, planowanie posiłków oraz monitorowanie postępów w osiąganiu celów zdrowotnych.
            </p>
            <p style={{ fontSize: 16, color: "#4a5568", lineHeight: 1.8 }}>
              Aplikacja została stworzona z myślą o osobach, które chcą w prosty sposób kontrolować 
              swoją dietę i osiągnąć wymarzoną sylwetkę.
            </p>
          </div>
  
          {/* Sekcja 2 */}
          <div style={{
            background: "linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%)",
            padding: 40,
            borderRadius: 20
          }}>
            <h2 style={{ fontSize: 28, fontWeight: 700, color: "#2d3748", marginBottom: 20 }}>
              ✨ Główne Funkcje
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 20 }}>
              {[
                { icon: "📊", title: "Dashboard", desc: "Podgląd dziennych statystyk i postępów" },
                { icon: "📚", title: "Biblioteka", desc: "Baza posiłków i produktów" },
                { icon: "📋", title: "Plany", desc: "Generator diet dopasowanych do celów" },
                { icon: "📈", title: "Analityka", desc: "Wykresy i trendy postępów" },
                { icon: "🔔", title: "Powiadomienia", desc: "Przypomnienia o posiłkach i celach" },
                { icon: "🎯", title: "Cele", desc: "Personalizowane cele kaloryczne" }
              ].map((feature, i) => (
                <div key={i} style={{
                  background: "white",
                  padding: 25,
                  borderRadius: 15,
                  boxShadow: "0 2px 10px rgba(0,0,0,0.05)"
                }}>
                  <div style={{ fontSize: 36, marginBottom: 10 }}>{feature.icon}</div>
                  <h3 style={{ fontSize: 18, fontWeight: 700, color: "#2d3748", marginBottom: 8 }}>
                    {feature.title}
                  </h3>
                  <p style={{ fontSize: 14, color: "#718096" }}>
                    {feature.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
  
          {/* Sekcja 3 */}
          <div style={{
            background: "white",
            padding: 40,
            borderRadius: 20,
            boxShadow: "0 4px 15px rgba(0,0,0,0.08)"
          }}>
            <h2 style={{ fontSize: 28, fontWeight: 700, color: "#2d3748", marginBottom: 20 }}>
              🛠️ Technologie
            </h2>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 15 }}>
              {['React', 'TypeScript', 'Node.js', 'Express', 'MySQL', 'Vite', 'React Query'].map((tech, i) => (
                <div key={i} style={{
                  padding: "10px 20px",
                  background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                  color: "white",
                  borderRadius: 10,
                  fontSize: 14,
                  fontWeight: 600
                }}>
                  {tech}
                </div>
              ))}
            </div>
          </div>
  
          {/* Sekcja 4 */}
          <div style={{
            background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
            padding: 40,
            borderRadius: 20,
            color: "white",
            textAlign: "center"
          }}>
            <h2 style={{ fontSize: 32, fontWeight: 700, marginBottom: 15 }}>
              🚀 Wersja Beta
            </h2>
            <p style={{ fontSize: 16, opacity: 0.9, marginBottom: 25 }}>
              FitMajster jest aktywnie rozwijany. Nowe funkcje pojawiają się regularnie!
            </p>
            <div style={{ fontSize: 14, opacity: 0.8 }}>
              Wersja: 2.0.0 | Ostatnia aktualizacja: Listopad 2025
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  export default About;
  