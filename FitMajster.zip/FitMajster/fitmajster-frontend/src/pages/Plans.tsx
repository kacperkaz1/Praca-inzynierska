import { useState, useEffect } from "react";
import Modal from "../components/Modal";

const Plans = () => {
  const [plans, setPlans] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isCustomModalOpen, setIsCustomModalOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<string>("");
  const [calories, setCalories] = useState<string>("");
  const [planName, setPlanName] = useState<string>("");
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [planDetails, setPlanDetails] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Stan dla niestandardowego planu
  const [customPlanName, setCustomPlanName] = useState("");
  const [customCalories, setCustomCalories] = useState("");
  const [customMeals, setCustomMeals] = useState<any>({});
  const [availableMeals, setAvailableMeals] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  const goals = [
    {
      id: "reduction",
      name: "🔥 Redukcja",
      icon: "🔥",
      description: "Deficyt kaloryczny, utrata wagi",
      gradient: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)"
    },
    {
      id: "maintenance",
      name: "⚖️ Utrzymanie",
      icon: "⚖️",
      description: "Bilans kaloryczny, utrzymanie wagi",
      gradient: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)"
    },
    {
      id: "mass",
      name: "💪 Masa Mięśniowa",
      icon: "💪",
      description: "Nadwyżka kaloryczna, budowa mięśni",
      gradient: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)"
    }
  ];

  useEffect(() => {
    loadPlans();
    loadAvailableMeals();
  }, []);

  const loadPlans = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/plans");
      const data = await response.json();
      setPlans(data);
    } catch (error) {
      console.error("Błąd ładowania planów:", error);
    }
  };

  const loadAvailableMeals = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/library/meals");
      const data = await response.json();
      setAvailableMeals(data);
    } catch (error) {
      console.error("Błąd ładowania posiłków:", error);
    }
  };

  const handleGeneratePlan = async () => {
    if (!selectedGoal || !calories || !planName) {
      alert("Wypełnij wszystkie pola!");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("http://localhost:5000/api/plans/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: selectedGoal,
          calories: parseInt(calories),
          name: planName
        })
      });

      const data = await response.json();
      if (response.ok) {
        alert("Plan wygenerowany!");
        setIsModalOpen(false);
        setSelectedGoal("");
        setCalories("");
        setPlanName("");
        loadPlans();
      } else {
        alert(data.error || "Błąd generowania planu");
      }
    } catch (error) {
      alert("Błąd połączenia z serwerem");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCustomPlan = async () => {
    if (!customPlanName || !customCalories) {
      alert("Podaj nazwę i kalorie planu!");
      return;
    }

    // Zbierz wybrane posiłki
    const mealsArray: any[] = [];
    Object.keys(customMeals).forEach(day => {
      Object.keys(customMeals[day]).forEach(time => {
        const mealId = customMeals[day][time];
        if (mealId) {
          mealsArray.push({
            day_number: parseInt(day),
            meal_id: mealId,
            meal_time: time
          });
        }
      });
    });

    try {
      const response = await fetch("http://localhost:5000/api/plans/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: customPlanName,
          calories: parseInt(customCalories),
          customMeals: mealsArray
        })
      });

      const data = await response.json();
      if (response.ok) {
        alert("Plan niestandardowy utworzony!");
        setIsCustomModalOpen(false);
        setCustomPlanName("");
        setCustomCalories("");
        setCustomMeals({});
        loadPlans();
      } else {
        alert(data.error || "Błąd tworzenia planu");
      }
    } catch (error) {
      alert("Błąd połączenia z serwerem");
    }
  };

  const handleViewPlan = async (plan: any) => {
    setSelectedPlan(plan);
    setLoading(true);
    try {
      const response = await fetch(`http://localhost:5000/api/plans/${plan.id}`);
      const data = await response.json();
      setPlanDetails(data);
      setIsViewModalOpen(true);
    } catch (error) {
      alert("Błąd ładowania szczegółów planu");
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePlan = async (id: number) => {
    if (!confirm("Czy na pewno chcesz usunąć ten plan?")) return;

    try {
      const response = await fetch(`http://localhost:5000/api/plans/${id}`, {
        method: "DELETE"
      });

      if (response.ok) {
        alert("Plan usunięty!");
        loadPlans();
      }
    } catch (error) {
      alert("Błąd usuwania planu");
    }
  };

  const setMealForDay = (day: number, time: string, mealId: number) => {
    setCustomMeals((prev: any) => ({
      ...prev,
      [day]: {
        ...prev[day],
        [time]: mealId
      }
    }));
  };

  const groupedDetails = () => {
    const grouped: any = {};
    planDetails.forEach(item => {
      if (!grouped[item.day_number]) {
        grouped[item.day_number] = [];
      }
      grouped[item.day_number].push(item);
    });
    return grouped;
  };

  const calculateDayCalories = (dayMeals: any[]) => {
    return dayMeals.reduce((sum, meal) => sum + (meal.kcal || 0), 0);
  };

  const selectedGoalInfo = goals.find(g => g.id === selectedGoal);

  const filteredMeals = availableMeals.filter(meal =>
    meal.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <h1 style={{
        fontSize: 42,
        fontWeight: 900,
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        WebkitBackgroundClip: "text",
        WebkitTextFillColor: "transparent",
        marginBottom: 10
      }}>
        Plany Żywieniowe
      </h1>

      <div style={{ display: "flex", gap: 15, marginBottom: 40 }}>
        <button
          onClick={() => setIsModalOpen(true)}
          style={{
            padding: "18px 35px",
            fontSize: 16,
            fontWeight: 700,
            color: "white",
            background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
            border: "none",
            borderRadius: 15,
            cursor: "pointer",
            boxShadow: "0 6px 20px rgba(102, 126, 234, 0.4)"
          }}
        >
          ✨ Wygeneruj Plan Automatycznie
        </button>

        <button
          onClick={() => setIsCustomModalOpen(true)}
          style={{
            padding: "18px 35px",
            fontSize: 16,
            fontWeight: 700,
            color: "white",
            background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
            border: "none",
            borderRadius: 15,
            cursor: "pointer",
            boxShadow: "0 6px 20px rgba(240, 147, 251, 0.4)"
          }}
        >
          🎨 Stwórz Plan Niestandardowy
        </button>
      </div>

      <h2 style={{ fontSize: 28, fontWeight: 700, marginBottom: 25, color: "#2d3748" }}>
        Moje Plany
      </h2>

      {plans.length === 0 ? (
        <div style={{ textAlign: "center", padding: 60, color: "#718096", fontSize: 18 }}>
          Brak planów. Wygeneruj swój pierwszy plan!
        </div>
      ) : (
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))",
          gap: 20
        }}>
          {plans.map(plan => (
            <div
              key={plan.id}
              style={{
                background: "white",
                padding: 25,
                borderRadius: 20,
                boxShadow: "0 4px 15px rgba(0,0,0,0.08)",
                border: "2px solid transparent",
                transition: "all 0.3s"
              }}
            >
              <h3 style={{ fontSize: 20, fontWeight: 700, color: "#2d3748", marginBottom: 10 }}>
                {plan.name}
              </h3>
              <p style={{ fontSize: 14, color: "#718096", marginBottom: 15 }}>
                {plan.description}
              </p>

              <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
                <button
                  onClick={() => handleViewPlan(plan)}
                  style={{
                    flex: 1,
                    padding: "12px",
                    fontSize: 14,
                    fontWeight: 600,
                    color: "white",
                    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                    border: "none",
                    borderRadius: 10,
                    cursor: "pointer"
                  }}
                >
                  🔍 Podgląd
                </button>
                <button
                  onClick={() => handleDeletePlan(plan.id)}
                  style={{
                    padding: "12px 20px",
                    fontSize: 14,
                    fontWeight: 600,
                    color: "white",
                    background: "linear-gradient(135deg, #f5576c 0%, #f093fb 100%)",
                    border: "none",
                    borderRadius: 10,
                    cursor: "pointer"
                  }}
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MODAL GENEROWANIA AUTOMATYCZNEGO */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Generuj Plan: Automatycznie ✨"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 25 }}>
          <div>
            <label style={{ display: "block", marginBottom: 12, fontWeight: 600, fontSize: 16 }}>
              Nazwa Planu *
            </label>
            <input
              type="text"
              value={planName}
              onChange={(e) => setPlanName(e.target.value)}
              placeholder="np. Mój Plan Redukcji"
              style={{
                width: "100%",
                padding: 14,
                fontSize: 16,
                border: "2px solid #e2e8f0",
                borderRadius: 10,
                outline: "none"
              }}
            />
          </div>

          <div>
            <label style={{ display: "block", marginBottom: 12, fontWeight: 600, fontSize: 16 }}>
              Typ planu
            </label>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
              {goals.map(goal => (
                <div
                  key={goal.id}
                  onClick={() => setSelectedGoal(goal.id)}
                  style={{
                    padding: "20px 15px",
                    borderRadius: 15,
                    cursor: "pointer",
                    border: selectedGoal === goal.id ? "3px solid #667eea" : "2px solid #e2e8f0",
                    background: selectedGoal === goal.id ? goal.gradient : "white",
                    color: selectedGoal === goal.id ? "white" : "#2d3748",
                    textAlign: "center",
                    fontWeight: 700,
                    fontSize: 14,
                    transition: "all 0.3s"
                  }}
                >
                  <div style={{ fontSize: 32, marginBottom: 8 }}>{goal.icon}</div>
                  <div>{goal.name}</div>
                </div>
              ))}
            </div>
            {selectedGoalInfo && (
              <div style={{
                marginTop: 15,
                padding: 15,
                background: selectedGoalInfo.gradient,
                color: "white",
                borderRadius: 12,
                fontSize: 14
              }}>
                <strong>{selectedGoalInfo.name}</strong>
                <div style={{ marginTop: 5, opacity: 0.9 }}>{selectedGoalInfo.description}</div>
              </div>
            )}
          </div>

          <div>
            <label style={{ display: "block", marginBottom: 12, fontWeight: 600, fontSize: 16 }}>
              Cel kaloryczny (kcal/dzień) *
            </label>
            <input
              type="number"
              value={calories}
              onChange={(e) => setCalories(e.target.value)}
              placeholder="np. 2400"
              style={{
                width: "100%",
                padding: 14,
                fontSize: 16,
                border: "2px solid #e2e8f0",
                borderRadius: 10,
                outline: "none"
              }}
            />
            <p style={{ fontSize: 13, color: "#718096", marginTop: 8 }}>
              System wygeneruje plan na 7 dni z gotowymi posiłkami z biblioteki.
            </p>
          </div>

          <button
            onClick={handleGeneratePlan}
            disabled={loading}
            style={{
              padding: "16px",
              fontSize: 16,
              fontWeight: 700,
              color: "white",
              background: loading ? "#cbd5e0" : "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
              border: "none",
              borderRadius: 12,
              cursor: loading ? "not-allowed" : "pointer",
              marginTop: 10
            }}
          >
            {loading ? "⏳ Generowanie..." : "✨ Wygeneruj Plan"}
          </button>
        </div>
      </Modal>

      {/* MODAL PLANU NIESTANDARDOWEGO */}
      <Modal
        isOpen={isCustomModalOpen}
        onClose={() => setIsCustomModalOpen(false)}
        title="Stwórz Plan Niestandardowy 🎨"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div>
            <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Nazwa Planu *</label>
            <input
              type="text"
              value={customPlanName}
              onChange={(e) => setCustomPlanName(e.target.value)}
              placeholder="np. Mój Tygodniowy Plan"
              style={{
                width: "100%",
                padding: 12,
                fontSize: 16,
                border: "2px solid #e2e8f0",
                borderRadius: 10,
                outline: "none"
              }}
            />
          </div>

          <div>
            <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Docelowe Kalorie (kcal/dzień) *</label>
            <input
              type="number"
              value={customCalories}
              onChange={(e) => setCustomCalories(e.target.value)}
              placeholder="np. 2200"
              style={{
                width: "100%",
                padding: 12,
                fontSize: 16,
                border: "2px solid #e2e8f0",
                borderRadius: 10,
                outline: "none"
              }}
            />
          </div>

          <div>
            <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Wyszukaj Posiłek</label>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="🔍 Szukaj posiłku..."
              style={{
                width: "100%",
                padding: 12,
                fontSize: 16,
                border: "2px solid #e2e8f0",
                borderRadius: 10,
                outline: "none"
              }}
            />
          </div>

          <div style={{ maxHeight: "400px", overflowY: "auto" }}>
            {[1, 2, 3, 4, 5, 6, 7].map(day => (
              <div key={day} style={{
                marginBottom: 20,
                padding: 15,
                background: "#f7fafc",
                borderRadius: 10
              }}>
                <h4 style={{ marginBottom: 15, color: "#2d3748" }}>Dzień {day}</h4>
                {['Śniadanie', 'Obiad', 'Kolacja', 'Przekąska'].map(time => (
                  <div key={time} style={{ marginBottom: 10 }}>
                    <label style={{ fontSize: 13, fontWeight: 600, display: "block", marginBottom: 5 }}>
                      {time}
                    </label>
                    <select
                      value={customMeals[day]?.[time] || ""}
                      onChange={(e) => setMealForDay(day, time, parseInt(e.target.value))}
                      style={{
                        width: "100%",
                        padding: 10,
                        fontSize: 14,
                        border: "1px solid #e2e8f0",
                        borderRadius: 8,
                        background: "white"
                      }}
                    >
                      <option value="">-- Wybierz posiłek --</option>
                      {filteredMeals
                        .filter(m => m.kategoria === time)
                        .map(meal => (
                          <option key={meal.id} value={meal.id}>
                            {meal.name} ({meal.total_calories} kcal)
                          </option>
                        ))}
                    </select>
                  </div>
                ))}
              </div>
            ))}
          </div>

          <button
            onClick={handleCreateCustomPlan}
            style={{
              padding: "15px",
              fontSize: 16,
              fontWeight: 700,
              color: "white",
              background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
              border: "none",
              borderRadius: 12,
              cursor: "pointer"
            }}
          >
            💾 Zapisz Plan
          </button>
        </div>
      </Modal>

      {/* MODAL PODGLĄDU PLANU */}
      <Modal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        title={`Podgląd: ${selectedPlan?.name || ""}`}
      >
        {loading ? (
          <div style={{ textAlign: "center", padding: 40 }}>
            <p style={{ fontSize: 18, color: "#718096" }}>⏳ Ładowanie szczegółów planu...</p>
          </div>
        ) : planDetails.length === 0 ? (
          <div style={{ textAlign: "center", padding: 40 }}>
            <p style={{ fontSize: 16, color: "#718096" }}>Brak szczegółów dla tego planu</p>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <div style={{
              padding: 15,
              background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
              borderRadius: 12,
              color: "white"
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                <span style={{ fontWeight: 600 }}>Cel kaloryczny</span>
                <span style={{ fontSize: 18, fontWeight: 700 }}>{selectedPlan?.calories} kcal/dzień</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ fontWeight: 600 }}>Dni</span>
                <span style={{ fontSize: 18, fontWeight: 700 }}>7</span>
              </div>
            </div>

            {Object.keys(groupedDetails()).map(day => {
              const dayMeals = groupedDetails()[day];
              const dayCalories = calculateDayCalories(dayMeals);

              return (
                <div key={day} style={{
                  padding: 20,
                  background: "#f7fafc",
                  borderRadius: 12,
                  border: "2px solid #e2e8f0"
                }}>
                  <div style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 15
                  }}>
                    <h3 style={{ fontSize: 18, fontWeight: 700, color: "#2d3748" }}>
                      Dzień {day}
                    </h3>
                    <span style={{
                      padding: "6px 12px",
                      background: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
                      color: "white",
                      borderRadius: 8,
                      fontSize: 14,
                      fontWeight: 700
                    }}>
                      {dayCalories} kcal
                    </span>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {dayMeals.map(meal => (
                      <div
                        key={meal.id}
                        style={{
                          padding: 15,
                          background: "white",
                          borderRadius: 10,
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center"
                        }}
                      >
                        <div>
                          <div style={{
                            fontSize: 12,
                            color: "#667eea",
                            fontWeight: 600,
                            marginBottom: 5
                          }}>
                            {meal.meal_time}
                          </div>
                          <div style={{ fontSize: 15, fontWeight: 600, color: "#2d3748" }}>
                            {meal.meal_name}
                          </div>
                        </div>
                        <div style={{
                          fontSize: 14,
                          fontWeight: 700,
                          color: "#f093fb"
                        }}>
                          {meal.kcal} kcal
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Plans;
