import { useState, useEffect } from "react";
import Modal from "../components/Modal";
import { api } from "../config/api";

const Journal = () => {
  const [products, setProducts] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: "",
    calories: "",
    protein: "",
    carbs: "",
    fat: ""
  });

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    const data = await api.getAllProducts();
    setProducts(data);
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length >= 2) {
      const data = await api.searchProducts(query);
      setProducts(data);
    } else {
      loadProducts();
    }
  };

  const handleAddProduct = async () => {
    if (!newProduct.name || !newProduct.calories) {
      alert("Wypełnij przynajmniej nazwę i kalorie!");
      return;
    }

    await api.addProduct(newProduct);
    setIsModalOpen(false);
    setNewProduct({ name: "", calories: "", protein: "", carbs: "", fat: "" });
    loadProducts();
  };

  return (
    <div>
      <h1 style={{
        fontSize: 42,
        fontWeight: 900,
        background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
        WebkitBackgroundClip: "text",
        WebkitTextFillColor: "transparent",
        marginBottom: 10
      }}>
        Biblioteka Posiłków
      </h1>
      <p style={{ fontSize: 18, color: "#718096", marginBottom: 40 }}>
        Przeglądaj produkty lub dodaj własne 📚
      </p>

      {/* Wyszukiwarka */}
      <div style={{ marginBottom: 30, display: "flex", gap: 15 }}>
        <input
          type="text"
          placeholder="🔍 Szukaj produktu..."
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value)}
          style={{
            flex: 1,
            padding: 18,
            fontSize: 16,
            border: "2px solid #e2e8f0",
            borderRadius: 15,
            outline: "none"
          }}
          onFocus={(e) => e.currentTarget.style.borderColor = "#f093fb"}
          onBlur={(e) => e.currentTarget.style.borderColor = "#e2e8f0"}
        />
        <button
          onClick={() => setIsModalOpen(true)}
          style={{
            padding: "18px 35px",
            fontSize: 16,
            fontWeight: 700,
            color: "white",
            background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
            border: "none",
            borderRadius: 15,
            cursor: "pointer",
            boxShadow: "0 6px 20px rgba(240, 147, 251, 0.4)"
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = "translateY(-3px)";
            e.currentTarget.style.boxShadow = "0 10px 30px rgba(240, 147, 251, 0.6)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = "translateY(0)";
            e.currentTarget.style.boxShadow = "0 6px 20px rgba(240, 147, 251, 0.4)";
          }}
        >
          ➕ Dodaj Produkt
        </button>
      </div>

      {/* Lista produktów */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
        gap: 20
      }}>
        {products.map((product) => (
          <div
            key={product.id}
            style={{
              background: "white",
              padding: 25,
              borderRadius: 20,
              boxShadow: "0 4px 15px rgba(0,0,0,0.08)",
              border: "2px solid transparent",
              cursor: "pointer"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = "#f093fb";
              e.currentTarget.style.transform = "translateY(-5px)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = "transparent";
              e.currentTarget.style.transform = "translateY(0)";
            }}
          >
            <h3 style={{
              fontSize: 18,
              fontWeight: 700,
              color: "#2d3748",
              marginBottom: 15
            }}>
              {product.name}
            </h3>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, fontSize: 14 }}>
              <div>
                <span style={{ color: "#718096" }}>Kalorie:</span>
                <div style={{ fontWeight: 700, color: "#f093fb" }}>{product.calories} kcal</div>
              </div>
              <div>
                <span style={{ color: "#718096" }}>Białko:</span>
                <div style={{ fontWeight: 700, color: "#667eea" }}>{product.protein}g</div>
              </div>
              <div>
                <span style={{ color: "#718096" }}>Węgle:</span>
                <div style={{ fontWeight: 700, color: "#4facfe" }}>{product.carbs}g</div>
              </div>
              <div>
                <span style={{ color: "#718096" }}>Tłuszcz:</span>
                <div style={{ fontWeight: 700, color: "#43e97b" }}>{product.fat}g</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal dodawania produktu */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Dodaj Nowy Produkt"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div>
            <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Nazwa produktu *</label>
            <input
              type="text"
              value={newProduct.name}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
              placeholder="np. Kurczak pierś"
              style={{
                width: "100%",
                padding: 12,
                fontSize: 16,
                border: "2px solid #e2e8f0",
                borderRadius: 10,
                outline: "none"
              }}
            />
          </div>
          
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 15 }}>
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Kalorie (na 100g) *</label>
              <input
                type="number"
                value={newProduct.calories}
                onChange={(e) => setNewProduct({ ...newProduct, calories: e.target.value })}
                placeholder="165"
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Białko (g)</label>
              <input
                type="number"
                value={newProduct.protein}
                onChange={(e) => setNewProduct({ ...newProduct, protein: e.target.value })}
                placeholder="31"
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Węglowodany (g)</label>
              <input
                type="number"
                value={newProduct.carbs}
                onChange={(e) => setNewProduct({ ...newProduct, carbs: e.target.value })}
                placeholder="0"
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Tłuszcze (g)</label>
              <input
                type="number"
                value={newProduct.fat}
                onChange={(e) => setNewProduct({ ...newProduct, fat: e.target.value })}
                placeholder="3.6"
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none"
                }}
              />
            </div>
          </div>

          <button
            onClick={handleAddProduct}
            style={{
              padding: "15px 30px",
              fontSize: 16,
              fontWeight: 700,
              color: "white",
              background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
              border: "none",
              borderRadius: 12,
              cursor: "pointer",
              marginTop: 10
            }}
          >
            💾 Zapisz Produkt
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default Journal;
