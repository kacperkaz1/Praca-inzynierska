import { useState, useEffect } from "react";
import Modal from "../components/Modal";
import { api } from "../config/api";

const Dashboard = () => {
  const [todayEntries, setTodayEntries] = useState<any[]>([]);
  const [stats, setStats] = useState<any>({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [addType, setAddType] = useState<'meal' | 'product' | null>(null);
  
  const [products, setProducts] = useState<any[]>([]);
  const [productSearch, setProductSearch] = useState("");
  
  const [meals, setMeals] = useState<any[]>([]);
  const [mealSearch, setMealSearch] = useState("");
  
  const [newEntry, setNewEntry] = useState({
    name: "Posiłek",
    item_id: "",
    quantity: "100",
    time: ""
  });

  const today = new Date().toISOString().split('T')[0];
  const TARGET_CALORIES = 2200;

  useEffect(() => {
    loadTodayData();
  }, []);

  // Zapisuje powiadomienia do bazy zamiast pokazywać popup
  const loadTodayData = async () => {
    const entries = await api.getDiaryByDate(today);
    const statistics = await api.getTodayStats();
    setTodayEntries(entries);
    setStats(statistics);
    
    await checkAndCreateNotification(statistics.total_calories);
  };

  // Zapisuje powiadomienia do bazy
  const checkAndCreateNotification = async (totalCalories: number) => {
    const percentage = (totalCalories / TARGET_CALORIES) * 100;
    
    let notification = null;
    
    if (percentage > 110) {
      notification = {
        title: "⚠️ Przekroczono limit!",
        message: `Osiągnąłeś ${Math.round(percentage)}% celu! (${Math.round(totalCalories)} / ${TARGET_CALORIES} kcal)`
      };
    } else if (percentage < 70 && totalCalories > 0) {
      notification = {
        title: "🍽️ Za mało kalorii!",
        message: `Osiągnąłeś tylko ${Math.round(percentage)}% celu. Zjedz jeszcze ${Math.round(TARGET_CALORIES - totalCalories)} kcal!`
      };
    } else if (percentage >= 90 && percentage <= 110 && totalCalories > 0) {
      notification = {
        title: "🎯 Świetnie!",
        message: `Perfekcyjnie! Osiągnąłeś ${Math.round(percentage)}% dziennego celu!`
      };
    }
    
    // Zapisz do bazy tylko jeśli jest powiadomienie
    if (notification) {
      try {
        await fetch("http://localhost:5000/api/notifications/create-manual", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: notification.title,
            message: notification.message
          })
        });
      } catch (error) {
        console.error("Błąd tworzenia powiadomienia:", error);
      }
    }
  };

  const openAddModal = (type: 'meal' | 'product') => {
    setAddType(type);
    setIsModalOpen(true);
    setNewEntry({ name: "Posiłek", item_id: "", quantity: "100", time: "" });
    setProductSearch("");
    setMealSearch("");
    setProducts([]);
    setMeals([]);
  };

  const handleSearchProducts = async (query: string) => {
    setProductSearch(query);
    if (query.length >= 2) {
      const data = await api.searchProducts(query);
      setProducts(data);
    } else {
      setProducts([]);
    }
  };

  const handleSearchMeals = async (query: string) => {
    setMealSearch(query);
    if (query.length >= 2) {
      const data = await api.searchLibraryMeals(query);
      setMeals(data);
    } else {
      setMeals([]);
    }
  };

  const handleAdd = async () => {
    if (!newEntry.item_id) {
      alert("Wybierz posiłek lub produkt z listy!");
      return;
    }

    if (addType === 'product' && (!newEntry.quantity || parseFloat(newEntry.quantity) <= 0)) {
      alert("Podaj ilość produktu!");
      return;
    }

    const data: any = {
      name: newEntry.name,
      date: today,
      time: newEntry.time || new Date().toTimeString().split(' ')[0],
      type: addType,
      quantity: parseFloat(newEntry.quantity) || 100
    };

    if (addType === 'meal') {
      data.meal_id = parseInt(newEntry.item_id);
    } else {
      data.product_id = parseInt(newEntry.item_id);
    }

    try {
      await api.addToDiary(data);
      alert("✅ Dodano do dziennika!");
      
      setIsModalOpen(false);
      setAddType(null);
      setNewEntry({ name: "Posiłek", item_id: "", quantity: "100", time: "" });
      setProductSearch("");
      setMealSearch("");
      setProducts([]);
      setMeals([]);
      loadTodayData(); // To również sprawdzi powiadomienia
    } catch (error) {
      alert("❌ Błąd podczas dodawania!");
      console.error(error);
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Usunąć ten wpis?")) {
      await api.deleteFromDiary(id);
      loadTodayData();
    }
  };

  const StatCard = ({ title, value, subtitle, gradient, icon, target }: any) => {
    const numValue = parseFloat(value) || 0;
    const percentage = target ? Math.min(100, (numValue / target) * 100) : 0;
    
    return (
      <div style={{
        background: gradient,
        borderRadius: 20,
        padding: "25px",
        color: "white",
        boxShadow: "0 8px 20px rgba(0,0,0,0.15)",
        position: "relative",
        overflow: "hidden"
      }}>
        <div style={{ fontSize: 36, marginBottom: 10 }}>{icon}</div>
        <div style={{ fontSize: 14, opacity: 0.9, marginBottom: 8 }}>{title}</div>
        <div style={{ fontSize: 32, fontWeight: 700, marginBottom: 5 }}>{value}</div>
        <div style={{ fontSize: 12, opacity: 0.8 }}>{subtitle}</div>
        {target && (
          <div style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            width: `${percentage}%`,
            height: 4,
            background: "rgba(255,255,255,0.5)",
            transition: "width 0.5s ease"
          }} />
        )}
      </div>
    );
  };

  return (
    <div>
      <h1 style={{
        fontSize: 42,
        fontWeight: 900,
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        WebkitBackgroundClip: "text",
        WebkitTextFillColor: "transparent",
        marginBottom: 10
      }}>
        Dashboard
      </h1>
      <p style={{ fontSize: 18, color: "#718096", marginBottom: 40 }}>
        {new Date().toLocaleDateString('pl-PL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} 🎯
      </p>
      
      {/* Statystyki */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
        gap: 20,
        marginBottom: 40
      }}>
        <StatCard 
          title="Kalorie"
          value={Math.round(stats.total_calories || 0)}
          subtitle={`cel: ${TARGET_CALORIES} kcal`}
          gradient="linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
          icon="🔥"
          target={TARGET_CALORIES}
        />
        <StatCard 
          title="Białko"
          value={`${Math.round(stats.total_protein || 0)}g`}
          subtitle="cel: 150g"
          gradient="linear-gradient(135deg, #f093fb 0%, #f5576c 100%)"
          icon="💪"
          target={150}
        />
        <StatCard 
          title="Węglowodany"
          value={`${Math.round(stats.total_carbs || 0)}g`}
          subtitle="cel: 250g"
          gradient="linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)"
          icon="🍚"
          target={250}
        />
        <StatCard 
          title="Tłuszcze"
          value={`${Math.round(stats.total_fat || 0)}g`}
          subtitle="cel: 70g"
          gradient="linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)"
          icon="🥑"
          target={70}
        />
      </div>

      {/* Dziennik */}
      <div style={{
        background: "linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%)",
        borderRadius: 20,
        padding: 30
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 25 }}>
          <h2 style={{ fontSize: 24, fontWeight: 700, color: "#2d3748" }}>
            Dziennik Posiłków 📝
          </h2>
          <div style={{ display: "flex", gap: 10 }}>
            <button
              onClick={() => openAddModal('meal')}
              style={{
                padding: "12px 20px",
                fontSize: 14,
                fontWeight: 700,
                color: "white",
                background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
                border: "none",
                borderRadius: 12,
                cursor: "pointer",
                boxShadow: "0 4px 15px rgba(240, 147, 251, 0.4)"
              }}
            >
              🍽️ Dodaj Posiłek
            </button>
            <button
              onClick={() => openAddModal('product')}
              style={{
                padding: "12px 20px",
                fontSize: 14,
                fontWeight: 700,
                color: "white",
                background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                border: "none",
                borderRadius: 12,
                cursor: "pointer",
                boxShadow: "0 4px 15px rgba(102, 126, 234, 0.4)"
              }}
            >
              🥗 Dodaj Produkt
            </button>
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
          {todayEntries.length === 0 ? (
            <div style={{ textAlign: "center", padding: 40, color: "#718096" }}>
              Brak wpisów na dzisiaj. Dodaj pierwszy! 🍽️
            </div>
          ) : (
            todayEntries.map((entry) => (
              <div key={entry.id} style={{
                background: "white",
                padding: "20px",
                borderRadius: 15,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                boxShadow: "0 2px 10px rgba(0,0,0,0.05)"
              }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 16, color: "#2d3748" }}>
                    {entry.name}
                  </div>
                  <div style={{ fontSize: 14, color: "#718096", marginTop: 5 }}>
                    ⏰ {entry.time?.substring(0, 5)} | {entry.item_name} 
                    {entry.type === 'product' && entry.quantity && entry.quantity !== 100 && ` (${entry.quantity}g)`}
                  </div>
                  <div style={{ fontSize: 13, color: "#4a5568", marginTop: 5 }}>
                    🔥 {entry.total_calories} kcal | 💪 {entry.total_protein}g B | 🍚 {entry.total_carbs}g W | 🥑 {entry.total_fat}g T
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(entry.id)}
                  style={{
                    background: "#ff4757",
                    color: "white",
                    border: "none",
                    borderRadius: 8,
                    padding: "8px 15px",
                    cursor: "pointer",
                    fontSize: 14
                  }}
                >
                  🗑️
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setAddType(null);
        }}
        title={addType === 'meal' ? "Dodaj Gotowy Posiłek" : "Dodaj Produkt"}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div>
            <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Nazwa wpisu</label>
            <input
              type="text"
              value={newEntry.name}
              onChange={(e) => setNewEntry({ ...newEntry, name: e.target.value })}
              placeholder="Śniadanie, Obiad..."
              style={{
                width: "100%",
                padding: 12,
                fontSize: 16,
                border: "2px solid #e2e8f0",
                borderRadius: 10,
                outline: "none"
              }}
            />
          </div>

          <div>
            <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>
              {addType === 'meal' ? '🔍 Szukaj posiłku' : '🔍 Szukaj produktu'}
            </label>
            <input
              type="text"
              value={addType === 'meal' ? mealSearch : productSearch}
              onChange={(e) => addType === 'meal' ? handleSearchMeals(e.target.value) : handleSearchProducts(e.target.value)}
              placeholder="Zacznij wpisywać nazwę..."
              style={{
                width: "100%",
                padding: 12,
                fontSize: 16,
                border: `2px solid ${newEntry.item_id ? '#43e97b' : '#e2e8f0'}`,
                borderRadius: 10,
                outline: "none"
              }}
            />
            {newEntry.item_id && (
              <div style={{ fontSize: 12, color: "#43e97b", marginTop: 5 }}>
                ✅ Wybrano
              </div>
            )}
          </div>

          {(addType === 'product' ? products : meals).length > 0 && (
            <div style={{
              maxHeight: 200,
              overflowY: "auto",
              border: "1px solid #e2e8f0",
              borderRadius: 10,
              padding: 10
            }}>
              {(addType === 'product' ? products : meals).map((item: any) => (
                <div
                  key={item.id}
                  onClick={() => {
                    setNewEntry({ ...newEntry, item_id: item.id.toString() });
                    if (addType === 'product') {
                      setProductSearch(item.name);
                      setProducts([]);
                    } else {
                      setMealSearch(item.name);
                      setMeals([]);
                    }
                  }}
                  style={{
                    padding: 12,
                    cursor: "pointer",
                    borderRadius: 8,
                    marginBottom: 5,
                    background: newEntry.item_id === item.id.toString() ? "#f0f4ff" : "transparent"
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = "#f0f4ff"}
                  onMouseLeave={(e) => e.currentTarget.style.background = newEntry.item_id === item.id.toString() ? "#f0f4ff" : "transparent"}
                >
                  <div style={{ fontWeight: 600 }}>{item.name}</div>
                  <div style={{ fontSize: 13, color: "#718096" }}>
                    {Math.round(item.calories || item.total_calories || 0)} kcal
                    {(item.protein !== undefined || item.total_protein !== undefined) && 
                      ` | ${Math.round(item.protein || item.total_protein || 0)}g B`
                    }
                  </div>
                </div>
              ))}
            </div>
          )}

          <div style={{ display: "grid", gridTemplateColumns: addType === 'product' ? "1fr 1fr" : "1fr", gap: 15 }}>
            {addType === 'product' && (
              <div>
                <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Ilość (g) *</label>
                <input
                  type="number"
                  value={newEntry.quantity}
                  onChange={(e) => setNewEntry({ ...newEntry, quantity: e.target.value })}
                  placeholder="200"
                  style={{
                    width: "100%",
                    padding: 12,
                    fontSize: 16,
                    border: "2px solid #e2e8f0",
                    borderRadius: 10,
                    outline: "none"
                  }}
                />
              </div>
            )}
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Godzina</label>
              <input
                type="time"
                value={newEntry.time}
                onChange={(e) => setNewEntry({ ...newEntry, time: e.target.value })}
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none"
                }}
              />
            </div>
          </div>

          <button
            onClick={handleAdd}
            style={{
              padding: "15px 30px",
              fontSize: 16,
              fontWeight: 700,
              color: "white",
              background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
              border: "none",
              borderRadius: 12,
              cursor: "pointer",
              marginTop: 10
            }}
          >
            ✅ Dodaj do Dziennika
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default Dashboard;
