const NotFound = () => {
    return (
      <div>
        <h1>404 - Nie znaleziono strony</h1>
        <a href="/">Wróć do strony głównej</a>
      </div>
    );
  };
  
  export default NotFound;
  