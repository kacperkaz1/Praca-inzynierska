import { useState, useEffect } from "react";
import Modal from "../components/Modal";
import { api } from "../config/api";

const Library = () => {
  const [items, setItems] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'meals' | 'products'>('meals');
  const [currentPage, setCurrentPage] = useState(1);
  const [newItem, setNewItem] = useState({
    name: "",
    calories: "",
    protein: "",
    carbs: "",
    fat: "",
    kategoria: "Obiad"
  });

  // Nowe stany dla kreatora posiłku
  const [productQuery, setProductQuery] = useState('');
  const [foundProducts, setFoundProducts] = useState<any[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<any[]>([]);

  const itemsPerPage = 12;

  useEffect(() => {
    loadItems();
    setCurrentPage(1);
  }, [viewMode, searchQuery]);

  // Wyszukiwanie produktów dla kreatora posiłku
  useEffect(() => {
    if(productQuery.length >= 2) {
      api.searchProducts(productQuery).then(setFoundProducts);
    } else {
      setFoundProducts([]);
    }
  }, [productQuery]);

  // Automatyczne sumowanie makro z wybranych produktów
  useEffect(() => {
    if(viewMode === 'meals' && selectedProducts.length > 0) {
      const macro = selectedProducts.reduce((sum, prod) => {
        const multiplier = (prod.amount || 100) / 100;
        return {
          calories: sum.calories + parseFloat(prod.calories || 0) * multiplier,
          protein: sum.protein + parseFloat(prod.protein || 0) * multiplier,
          carbs: sum.carbs + parseFloat(prod.carbs || 0) * multiplier,
          fat: sum.fat + parseFloat(prod.fat || 0) * multiplier
        };
      }, { calories: 0, protein: 0, carbs: 0, fat: 0 });

      setNewItem(i => ({
        ...i,
        calories: Math.round(macro.calories).toString(),
        protein: Math.round(macro.protein).toString(),
        carbs: Math.round(macro.carbs).toString(),
        fat: Math.round(macro.fat).toString()
      }));
    }
  }, [selectedProducts, viewMode]);

  const loadItems = async () => {
    if (viewMode === 'meals') {
      const data = await api.searchLibraryMeals(searchQuery);
      setItems(data);
    } else {
      if (searchQuery.length >= 2) {
        const data = await api.searchProducts(searchQuery);
        setItems(data);
      } else {
        const data = await api.getAllProducts();
        setItems(data);
      }
    }
  };

  const handleAdd = async () => {
    if (!newItem.name || !newItem.calories) {
      alert("Wypełnij przynajmniej nazwę i kalorie!");
      return;
    }

    if (viewMode === 'meals') {
      const ingredients = selectedProducts.map(p => `${p.name} (${p.amount}g)`).join(', ');
      
      const response = await fetch('http://localhost:5000/api/meals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newItem.name,
          kategoria: newItem.kategoria,
          kcal: newItem.calories,
          bialko: newItem.protein || 0,
          weglowodany: newItem.carbs || 0,
          tluszcze: newItem.fat || 0,
          notes: ingredients
        })
      });
      
      if (response.ok) {
        alert("Posiłek dodany!");
      }
    } else {
      await api.addProduct(newItem);
      alert("Produkt dodany!");
    }

    setIsModalOpen(false);
    setNewItem({ name: "", calories: "", protein: "", carbs: "", fat: "", kategoria: "Obiad" });
    setSelectedProducts([]);
    setProductQuery('');
    loadItems();
  };

  const totalPages = Math.ceil(items.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentItems = items.slice(startIndex, startIndex + itemsPerPage);

  return (
    <div>
      <h1 style={{
        fontSize: 42,
        fontWeight: 900,
        background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
        WebkitBackgroundClip: "text",
        WebkitTextFillColor: "transparent",
        marginBottom: 10
      }}>
        Biblioteka Posiłków
      </h1>
      <p style={{ fontSize: 18, color: "#718096", marginBottom: 40 }}>
        Przeglądaj gotowe posiłki lub pojedyncze produkty 📚
      </p>

      <div style={{ display: "flex", gap: 10, marginBottom: 30 }}>
        <button
          onClick={() => setViewMode('meals')}
          style={{
            padding: "12px 25px",
            fontSize: 15,
            fontWeight: 700,
            color: viewMode === 'meals' ? "white" : "#667eea",
            background: viewMode === 'meals' 
              ? "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
              : "white",
            border: "2px solid #667eea",
            borderRadius: 12,
            cursor: "pointer",
            boxShadow: viewMode === 'meals' ? "0 4px 15px rgba(102, 126, 234, 0.4)" : "none"
          }}
        >
          🍽️ Gotowe Posiłki
        </button>
        <button
          onClick={() => setViewMode('products')}
          style={{
            padding: "12px 25px",
            fontSize: 15,
            fontWeight: 700,
            color: viewMode === 'products' ? "white" : "#f093fb",
            background: viewMode === 'products' 
              ? "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)"
              : "white",
            border: "2px solid #f093fb",
            borderRadius: 12,
            cursor: "pointer",
            boxShadow: viewMode === 'products' ? "0 4px 15px rgba(240, 147, 251, 0.4)" : "none"
          }}
        >
          🥗 Pojedyncze Produkty
        </button>
      </div>

      <div style={{ marginBottom: 30, display: "flex", gap: 15 }}>
        <input
          type="text"
          placeholder={viewMode === 'meals' ? "🔍 Szukaj posiłku..." : "🔍 Szukaj produktu..."}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{
            flex: 1,
            padding: 18,
            fontSize: 16,
            border: "2px solid #e2e8f0",
            borderRadius: 15,
            outline: "none"
          }}
          onFocus={(e) => e.currentTarget.style.borderColor = "#f093fb"}
          onBlur={(e) => e.currentTarget.style.borderColor = "#e2e8f0"}
        />
        <button
          onClick={() => setIsModalOpen(true)}
          style={{
            padding: "18px 35px",
            fontSize: 16,
            fontWeight: 700,
            color: "white",
            background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
            border: "none",
            borderRadius: 15,
            cursor: "pointer",
            boxShadow: "0 6px 20px rgba(240, 147, 251, 0.4)"
          }}
        >
          ➕ {viewMode === 'meals' ? 'Dodaj Posiłek' : 'Dodaj Produkt'}
        </button>
      </div>

      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
        gap: 20,
        marginBottom: 30
      }}>
        {currentItems.map((item) => (
          <div
            key={item.id}
            style={{
              background: "white",
              padding: 25,
              borderRadius: 20,
              boxShadow: "0 4px 15px rgba(0,0,0,0.08)",
              border: "2px solid transparent",
              cursor: "pointer",
              transition: "all 0.3s"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = "#f093fb";
              e.currentTarget.style.transform = "translateY(-5px)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = "transparent";
              e.currentTarget.style.transform = "translateY(0)";
            }}
          >
            <h3 style={{
              fontSize: 18,
              fontWeight: 700,
              color: "#2d3748",
              marginBottom: 15
            }}>
              {item.name}
            </h3>
            
            {viewMode === 'meals' && item.ingredients && (
              <div style={{ 
                fontSize: 13, 
                color: "#718096", 
                marginBottom: 15,
                fontStyle: "italic"
              }}>
                {item.ingredients}
              </div>
            )}

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, fontSize: 14 }}>
              <div>
                <span style={{ color: "#718096" }}>Kalorie:</span>
                <div style={{ fontWeight: 700, color: "#f093fb" }}>
                  {viewMode === 'meals'
                    ? Math.round(item.total_calories || 0)
                    : Math.round(item.calories || 0)
                  } kcal
                </div>
              </div>
              <div>
                <span style={{ color: "#718096" }}>Białko:</span>
                <div style={{ fontWeight: 700, color: "#667eea" }}>
                  {viewMode === 'meals'
                    ? Math.round(item.total_protein || 0)
                    : Math.round(item.protein || 0)
                  }g
                </div>
              </div>
              <div>
                <span style={{ color: "#718096" }}>Węgle:</span>
                <div style={{ fontWeight: 700, color: "#4facfe" }}>
                  {viewMode === 'meals'
                    ? Math.round(item.total_carbs || 0)
                    : Math.round(item.carbs || 0)
                  }g
                </div>
              </div>
              <div>
                <span style={{ color: "#718096" }}>Tłuszcz:</span>
                <div style={{ fontWeight: 700, color: "#43e97b" }}>
                  {viewMode === 'meals'
                    ? Math.round(item.total_fat || 0)
                    : Math.round(item.fat || 0)
                  }g
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {totalPages > 1 && (
        <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 30 }}>
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            style={{
              padding: "10px 20px",
              fontSize: 14,
              fontWeight: 600,
              color: currentPage === 1 ? "#cbd5e0" : "white",
              background: currentPage === 1 ? "#e2e8f0" : "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
              border: "none",
              borderRadius: 10,
              cursor: currentPage === 1 ? "not-allowed" : "pointer"
            }}
          >
            ← Poprzednia
          </button>
          
          <div style={{ display: "flex", gap: 5 }}>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                style={{
                  padding: "10px 15px",
                  fontSize: 14,
                  fontWeight: 600,
                  color: page === currentPage ? "white" : "#667eea",
                  background: page === currentPage 
                    ? "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
                    : "white",
                  border: "2px solid #667eea",
                  borderRadius: 10,
                  cursor: "pointer"
                }}
              >
                {page}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            style={{
              padding: "10px 20px",
              fontSize: 14,
              fontWeight: 600,
              color: currentPage === totalPages ? "#cbd5e0" : "white",
              background: currentPage === totalPages ? "#e2e8f0" : "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
              border: "none",
              borderRadius: 10,
              cursor: currentPage === totalPages ? "not-allowed" : "pointer"
            }}
          >
            Następna →
          </button>
        </div>
      )}

      {items.length === 0 && (
        <div style={{ textAlign: "center", padding: 60, color: "#718096", fontSize: 18 }}>
          {searchQuery 
            ? `Nie znaleziono "${searchQuery}".`
            : "Brak elementów w bibliotece."
          }
        </div>
      )}

      {/* Modal dodawania */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedProducts([]);
          setProductQuery('');
        }}
        title={viewMode === 'meals' ? "Dodaj Nowy Posiłek" : "Dodaj Nowy Produkt"}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div>
            <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Nazwa *</label>
            <input
              type="text"
              value={newItem.name}
              onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
              placeholder={viewMode === 'meals' ? "np. Kurczak z ryżem" : "np. Kurczak pierś"}
              style={{
                width: "100%",
                padding: 12,
                fontSize: 16,
                border: "2px solid #e2e8f0",
                borderRadius: 10,
                outline: "none"
              }}
            />
          </div>

          {viewMode === 'meals' && (
            <>
              <div>
                <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Kategoria *</label>
                <select
                  value={newItem.kategoria}
                  onChange={(e) => setNewItem({ ...newItem, kategoria: e.target.value })}
                  style={{
                    width: "100%",
                    padding: 12,
                    fontSize: 16,
                    border: "2px solid #e2e8f0",
                    borderRadius: 10,
                    outline: "none"
                  }}
                >
                  <option value="Śniadanie">Śniadanie</option>
                  <option value="Obiad">Obiad</option>
                  <option value="Kolacja">Kolacja</option>
                  <option value="Przekąska">Przekąska</option>
                </select>
              </div>

              {/* KREATOR POSIŁKU - Wyszukiwanie produktów */}
              <div>
                <label style={{ fontWeight: 600, marginBottom: 8, display: "block" }}>🔍 Wyszukaj Produkt</label>
                <input
                  type="text"
                  value={productQuery}
                  onChange={e => setProductQuery(e.target.value)}
                  placeholder="np. Kurczak, Ryż"
                  style={{
                    width: "100%",
                    padding: 12,
                    fontSize: 16,
                    border: "2px solid #e2e8f0",
                    borderRadius: 10,
                  }}
                />
                {foundProducts.length > 0 && (
                  <div style={{ 
                    background: "#fff", 
                    border: "1px solid #eee", 
                    borderRadius: 7, 
                    marginTop: 6, 
                    maxHeight: 180, 
                    overflowY: "auto" 
                  }}>
                    {foundProducts.map(prod => (
                      <div key={prod.id} style={{ 
                        display: "flex", 
                        alignItems: "center", 
                        padding: "8px 12px", 
                        borderBottom: "1px solid #eee" 
                      }}>
                        <span style={{ flex: 1, fontSize: 14 }}>{prod.name}</span>
                        <input
                          type="number"
                          min={0}
                          defaultValue={100}
                          placeholder="gram"
                          style={{ margin: "0 12px", width: 70, padding: "4px 8px", borderRadius: 5, border: "1px solid #ccc" }}
                          onChange={e => prod.inputAmount = e.target.value}
                        />
                        <button
                          style={{ 
                            background: "#43e97b", 
                            color: "#fff", 
                            border: "none", 
                            padding: "4px 12px", 
                            borderRadius: 7, 
                            cursor: "pointer",
                            fontSize: 13
                          }}
                          onClick={() => {
                            const amount = parseInt(prod.inputAmount || "100");
                            setSelectedProducts([...selectedProducts, { ...prod, amount }]);
                            setProductQuery('');
                            setFoundProducts([]);
                          }}
                        >
                          Dodaj
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {selectedProducts.length > 0 && (
                  <div style={{ marginTop: 12, padding: 12, background: "#f7fafc", borderRadius: 10 }}>
                    <strong style={{ fontSize: 14 }}>Składniki gotowego posiłku:</strong>
                    <ul style={{ paddingLeft: 20, marginTop: 8 }}>
                      {selectedProducts.map((prod, i) => (
                        <li key={i} style={{ fontSize: 14, marginBottom: 6 }}>
                          {prod.name} - {prod.amount} g{" "}
                          <button
                            style={{ 
                              marginLeft: 8, 
                              color: "#f093fb", 
                              background: "none", 
                              border: "none", 
                              cursor: "pointer",
                              textDecoration: "underline"
                            }}
                            onClick={() => setSelectedProducts(selectedProducts.filter((_, idx) => i !== idx))}
                          >
                            Usuń
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </>
          )}
          
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 15 }}>
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>
                Kalorie {viewMode === 'products' && '(na 100g)'} *
              </label>
              <input
                type="number"
                value={newItem.calories}
                onChange={(e) => setNewItem({ ...newItem, calories: e.target.value })}
                placeholder="165"
                disabled={viewMode === 'meals' && selectedProducts.length > 0}
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none",
                  background: (viewMode === 'meals' && selectedProducts.length > 0) ? "#f7fafc" : "white"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Białko (g)</label>
              <input
                type="number"
                value={newItem.protein}
                onChange={(e) => setNewItem({ ...newItem, protein: e.target.value })}
                placeholder="31"
                disabled={viewMode === 'meals' && selectedProducts.length > 0}
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none",
                  background: (viewMode === 'meals' && selectedProducts.length > 0) ? "#f7fafc" : "white"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Węglowodany (g)</label>
              <input
                type="number"
                value={newItem.carbs}
                onChange={(e) => setNewItem({ ...newItem, carbs: e.target.value })}
                placeholder="0"
                disabled={viewMode === 'meals' && selectedProducts.length > 0}
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none",
                  background: (viewMode === 'meals' && selectedProducts.length > 0) ? "#f7fafc" : "white"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Tłuszcze (g)</label>
              <input
                type="number"
                value={newItem.fat}
                onChange={(e) => setNewItem({ ...newItem, fat: e.target.value })}
                placeholder="3.6"
                disabled={viewMode === 'meals' && selectedProducts.length > 0}
                style={{
                  width: "100%",
                  padding: 12,
                  fontSize: 16,
                  border: "2px solid #e2e8f0",
                  borderRadius: 10,
                  outline: "none",
                  background: (viewMode === 'meals' && selectedProducts.length > 0) ? "#f7fafc" : "white"
                }}
              />
            </div>
          </div>

          <button
            onClick={handleAdd}
            style={{
              padding: "15px 30px",
              fontSize: 16,
              fontWeight: 700,
              color: "white",
              background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
              border: "none",
              borderRadius: 12,
              cursor: "pointer",
              marginTop: 10
            }}
          >
            💾 Zapisz
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default Library;
