import { useState, useEffect } from "react";

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [showPanel, setShowPanel] = useState(false);

  useEffect(() => {
    loadNotifications();
    // Automatyczne sprawdzanie co 5 minut
    const interval = setInterval(loadNotifications, 300000);
    return () => clearInterval(interval);
  }, []);

  const loadNotifications = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/notifications");
      const data = await response.json();
      setNotifications(data.filter(n => n.is_sent === 0));
    } catch (error) {
      console.error("Błąd ładowania powiadomień:", error);
    }
  };

  const markAsRead = async (id: number) => {
    try {
      await fetch(`http://localhost:5000/api/notifications/${id}/read`, {
        method: "PUT"
      });
      loadNotifications();
    } catch (error) {
      console.error("Błąd oznaczania powiadomienia:", error);
    }
  };

  const unreadCount = notifications.length;

  return (
    <div style={{ position: "fixed", top: 20, right: 20, zIndex: 1000 }}>
      {/* Ikona dzwonka */}
      <button
        onClick={() => setShowPanel(!showPanel)}
        style={{
          padding: "12px 16px",
          fontSize: 24,
          background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
          border: "none",
          borderRadius: 50,
          cursor: "pointer",
          boxShadow: "0 4px 15px rgba(102, 126, 234, 0.4)",
          position: "relative"
        }}
      >
        🔔
        {unreadCount > 0 && (
          <span style={{
            position: "absolute",
            top: -5,
            right: -5,
            background: "#f5576c",
            color: "white",
            borderRadius: 50,
            width: 24,
            height: 24,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 12,
            fontWeight: 700
          }}>
            {unreadCount}
          </span>
        )}
      </button>

      {/* Panel powiadomień */}
      {showPanel && (
        <div style={{
          position: "absolute",
          top: 60,
          right: 0,
          width: 350,
          maxHeight: 500,
          background: "white",
          borderRadius: 15,
          boxShadow: "0 8px 30px rgba(0,0,0,0.15)",
          overflow: "hidden"
        }}>
          <div style={{
            padding: "15px 20px",
            background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
            color: "white",
            fontWeight: 700,
            fontSize: 16
          }}>
            Powiadomienia ({unreadCount})
          </div>

          <div style={{
            maxHeight: 400,
            overflowY: "auto",
            padding: 10
          }}>
            {notifications.length === 0 ? (
              <div style={{ padding: 30, textAlign: "center", color: "#a0aec0" }}>
                Brak nowych powiadomień
              </div>
            ) : (
              notifications.map((notif: any) => (
                <div
                  key={notif.id}
                  style={{
                    padding: 15,
                    margin: "5px 0",
                    background: "#f7fafc",
                    borderRadius: 10,
                    borderLeft: "4px solid #667eea"
                  }}
                >
                  <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 5 }}>
                    {notif.title}
                  </div>
                  <div style={{ fontSize: 13, color: "#4a5568", marginBottom: 8 }}>
                    {notif.message}
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <small style={{ color: "#a0aec0" }}>
                      {new Date(notif.time).toLocaleString('pl-PL')}
                    </small>
                    <button
                      onClick={() => markAsRead(notif.id)}
                      style={{
                        padding: "5px 12px",
                        fontSize: 12,
                        background: "#48bb78",
                        color: "white",
                        border: "none",
                        borderRadius: 5,
                        cursor: "pointer"
                      }}
                    >
                      ✓ Przeczytane
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Notifications;
